package com.app.tagglifedatingapp.location

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.location.*
import android.os.Bundle
import android.util.Log
import com.app.tagglifedatingapp.utility.Logs
import java.io.IOException
import java.util.*

class LocationProvider(private val context: Context) : LocationListener {

    companion object {

        val locationPermissions = arrayOf(
            Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION
        )

        const val PERMISSION_REQUEST_CODE = 110
        const val REQUEST_START_GPS_FROM_SETTING = 102

        //TODO : The minimum distance to change Updates in meters
        private const val MIN_DISTANCE_CHANGE_FOR_UPDATES: Long = 10 // 10 meters

        //TODO : The minimum time between updates in milliseconds
        private const val MIN_TIME_BW_UPDATES = (1000 * 60).toLong() // 1 minute
    }

    interface OnUpdateLocation {
        fun onLocationUpdate(latitude: Double, longitude: Double, address: String = "")
    }

    private val TAG = LocationProvider::class.java.simpleName

    private var isGPSEnabled = false
    private var isNetworkEnabled = false
    /**
     * Function to check GPS/wifi enabled
     *
     * @return boolean
     */
    private var isGPSTrackingEnabled = false

    private var location: Location? = null
    private var latitude: Double = 0.toDouble()
    private var longitude: Double = 0.toDouble()

    // How many Geocoder should return our LocationProvider
    private var geocoderMaxResults = 1

    private val locationUpdateList = mutableListOf<OnUpdateLocation>()

    private lateinit var locationManager: LocationManager

    init {
        getLocation()
    }

    private fun getLocation(): Location? {
        try {
            locationManager = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager

            //TODO : Getting GPS status
            isGPSEnabled = locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)

            //TODO : Getting network status
            isNetworkEnabled = locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)

            if (isGPSEnabled || isNetworkEnabled) {
                this.isGPSTrackingEnabled = true
                try {
                    if (isNetworkEnabled) {
                        locationManager.requestLocationUpdates(
                            LocationManager.NETWORK_PROVIDER, MIN_TIME_BW_UPDATES,
                            MIN_DISTANCE_CHANGE_FOR_UPDATES.toFloat(), this
                        )
                        location = locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER)
                        if (location != null) {
                            latitude = location!!.latitude
                            longitude = location!!.longitude
                        }

                        if ((latitude == 0.0) && (longitude == 0.0)) {
                            // TODO : If GPS Enabled get lat/long using GPS Services
                            getLocationFromGps()
                            /*if (isGPSEnabled) {
                                if (location == null) {
                                    locationManager.requestLocationUpdates(
                                        LocationManager.GPS_PROVIDER, MIN_TIME_BW_UPDATES,
                                        MIN_DISTANCE_CHANGE_FOR_UPDATES.toFloat(), this
                                    )
                                }
                                location = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER)
                                if (location != null) {
                                    latitude = location!!.latitude
                                    longitude = location!!.longitude
                                }
                            }*/
                        }

                        /*if (isGPSEnabled) {
                            if (location == null) {
                                locationManager.requestLocationUpdates(
                                    LocationManager.GPS_PROVIDER, MIN_TIME_BW_UPDATES,
                                    MIN_DISTANCE_CHANGE_FOR_UPDATES.toFloat(), this
                                )
                                location =
                                    locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER)
                                if (location != null) {
                                    latitude = location!!.latitude
                                    longitude = location!!.longitude
                                }
                            }
                        }*/
                    } else if (isGPSEnabled) {
                        // TODO : If GPS Enabled get lat/long using GPS Services
                        getLocationFromGps()
                        /*if (location == null) {
                            locationManager.requestLocationUpdates(
                                LocationManager.GPS_PROVIDER, MIN_TIME_BW_UPDATES,
                                MIN_DISTANCE_CHANGE_FOR_UPDATES.toFloat(), this
                            )
                        }
                        location = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER)
                        if (location != null) {
                            latitude = location!!.latitude
                            longitude = location!!.longitude
                        }*/
                    }
                } catch (e: SecurityException) {
                    Logs.printMessages(TAG, e.message)
                } catch (e: Exception) {
                    Logs.printMessages(TAG, e.message)
                }
            }
            Logs.printMessages("$TAG location --> ", "$latitude --- $longitude")
        } catch (e: Exception) {
            Logs.printMessages(TAG, e.message)
        }

        return location
    }

    private fun getLocationFromGps() {
        try {
            if (isGPSEnabled) {
                if (location == null) {
                    locationManager.requestLocationUpdates(
                        LocationManager.GPS_PROVIDER, MIN_TIME_BW_UPDATES,
                        MIN_DISTANCE_CHANGE_FOR_UPDATES.toFloat(), this
                    )
                }
                location = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER)
                if (location != null) {
                    latitude = location!!.latitude
                    longitude = location!!.longitude
                }
            }
        } catch (e: SecurityException) {
            Logs.printMessages(TAG, e.message)
        } catch (e: Exception) {
            Logs.printMessages(TAG, e.message)
        }
    }

    fun setOnLocationUpdateListener(onUpdateLocation: OnUpdateLocation) =
        locationUpdateList.add(onUpdateLocation)

    fun isGpsEnabled(): Boolean {
        getLocation()
        return isGPSTrackingEnabled
    }

    fun refreshLocation(): MutableList<Double> {
        getLocation()
        return mutableListOf(latitude, longitude)
    }

    /**
     * Stop using GPS listener Calling this function will stop using GPS in your
     * app
     */
    @SuppressLint("NewApi")
    fun stopUsingGPS() {

        if (context.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
            && context.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED
        ) {
            // TO DO: Consider calling
            //    public void requestPermissions(@NonNull String[] permissions, int requestCode)
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for Activity#requestPermissions for more details.
            return
        }
        locationManager.removeUpdates(this)
    }

    /**
     * Update LocationProvider latitude and longitude
     */
    fun updateGPSCoordinates() {
        if (location != null) {
            latitude = location!!.latitude
            longitude = location!!.longitude
        }
    }

    /**
     * Function to get latitude
     */
    fun getLatitude(): Double {
        if (location != null) {
            latitude = location!!.latitude
            if ((longitude == 0.0) && (latitude == 0.0)) getLocation()
        } else getLocation()
        return latitude
    }

    /**
     * Function to get longitude
     */
    fun getLongitude(): Double {
        if (location != null) {
            longitude = location!!.longitude
            if ((longitude == 0.0) && (latitude == 0.0)) getLocation()
        } else getLocation()
        return longitude
    }

    /**
     * Get list of address by latitude and longitude
     *
     * @return null or List<Address>
    </Address> */
    fun getGeocoderAddress(context: Context): List<Address>? {
        if (location != null) {
            val geocoder = Geocoder(context, Locale.ENGLISH)
            try {
                /**
                 * Geocoder.getFromLocation - Returns an array of Addresses that
                 * are known to describe the area immediately surrounding the
                 * given latitude and longitude.
                 */
                return geocoder.getFromLocation(latitude, longitude, this.geocoderMaxResults)
            } catch (e: IOException) {
                // e.printStackTrace();
                Log.e(TAG, "Impossible to connect to Geocoder", e)
            }

        }
        return null
    }

    fun getAddressLine(context: Context): String? {
        val addresses = getGeocoderAddress(context)
        return if (addresses != null && addresses.isNotEmpty()) {
            val address = addresses[0]
            address.getAddressLine(0)
        } else
            null
    }

    fun getLocality(context: Context): String? {
        val addresses = getGeocoderAddress(context)
        return if (addresses != null && addresses.isNotEmpty()) {
            val address = addresses[0]
            address.locality
        } else
            null

    }

    fun getPostalCode(context: Context): String? {
        val addresses = getGeocoderAddress(context)
        return if (addresses != null && addresses.isNotEmpty()) {
            val address = addresses[0]
            address.postalCode
        } else
            null
    }

    fun getCountryName(context: Context): String? {
        val addresses = getGeocoderAddress(context)
        return if (addresses != null && addresses.isNotEmpty()) {
            val address = addresses[0]
            address.countryName
        } else
            null
    }

    override fun onLocationChanged(location: Location) {
        latitude = location.latitude
        longitude = location.longitude
        Logs.printMessages(TAG, getAddressLine(context) ?: "")
        locationUpdateList.forEach {
            it.onLocationUpdate(latitude, longitude, getAddressLine(context) ?: "")
        }
    }

    override fun onStatusChanged(provider: String, status: Int, extras: Bundle) {}

    override fun onProviderEnabled(provider: String) {}

    override fun onProviderDisabled(provider: String) {}
}