package com.narola.kotlinmvvmframework.ui.login.view

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.lifecycle.Observer
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.ApiException
import com.narola.kotlinmvvmframework.R
import com.narola.kotlinmvvmframework.base.BaseActivity
import com.narola.kotlinmvvmframework.base.extentions.getViewModel
import com.narola.kotlinmvvmframework.base.extentions.startActivityWithDefaultAnimations
import com.narola.kotlinmvvmframework.base.rxjava.autoDispose
import com.narola.kotlinmvvmframework.base.rxjava.throttleClicks
import com.narola.kotlinmvvmframework.api.auth.models.LoginResult
import com.narola.kotlinmvvmframework.ui.login.viewmodel.LoginViewModel
import com.narola.kotlinmvvmframework.ui.main.view.MainActivity
import com.narola.kotlinmvvmframework.ui.register.view.RegisterActivity
import kotlinx.android.synthetic.main.activity_login.*
import timber.log.Timber
import java.lang.Exception

class LoginActivity : BaseActivity() {

    private lateinit var viewModel: LoginViewModel

    companion object {
        private const val RC_SIGN_IN = 101
        fun getIntent(context: Context): Intent {
            val intent = Intent(context, LoginActivity::class.java)
            return intent
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)
        viewModel = getViewModel { LoginViewModel(authRepository = authRepository) }
        viewModel.loginResultObserver.observe(this, Observer<LoginResult> { loginResult ->
            if (loginResult?.isSuccess == true) {
                Toast.makeText(this, "Login Successful", Toast.LENGTH_LONG).show()
                startActivityWithDefaultAnimations(MainActivity.getIntent(this))
            } else {
                Toast.makeText(this, loginResult?.error?.localizedMessage, Toast.LENGTH_LONG).show()
            }
        })
        login.throttleClicks().subscribe {
            val email = loginEmail.text.toString()
            val password = loginPassword.text.toString()
            if (email.isNotEmpty() && password.isNotEmpty()) {
                viewModel.loginWithEmailPassword(email, password)
            }
        }.autoDispose(compositeDisposable)

        register.throttleClicks().subscribe {
            startActivityWithDefaultAnimations(RegisterActivity.getIntent(this))
        }.autoDispose(compositeDisposable)

        loginWithGoogle.throttleClicks().subscribe {
            val gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                    .requestIdToken(getString(R.string.default_web_client_id))
                    .requestEmail()
                    .build()
            val googleSignInClient = GoogleSignIn.getClient(this, gso)
            val signInIntent = googleSignInClient.signInIntent
            startActivityForResult(signInIntent, RC_SIGN_IN)
        }.autoDispose(compositeDisposable)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == RC_SIGN_IN) {
            try {
                val task = GoogleSignIn.getSignedInAccountFromIntent(data)
                val account = task.getResult(ApiException::class.java)
                account?.let {
                    viewModel.loginWithGoogle(account)
                }
            }catch (ex:Exception){
                Timber.e(ex)
            }

        }
    }
}