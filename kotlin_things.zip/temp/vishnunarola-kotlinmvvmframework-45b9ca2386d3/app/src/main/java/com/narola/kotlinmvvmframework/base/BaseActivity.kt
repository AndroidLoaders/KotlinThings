package com.narola.kotlinmvvmframework.base

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.narola.kotlinmvvmframework.api.auth.AuthRepository
import com.narola.kotlinmvvmframework.api.service.ApiService
import com.narola.kotlinmvvmframework.api.service.AppService
import com.narola.kotlinmvvmframework.base.network.NetworkObserver
import io.reactivex.disposables.CompositeDisposable

open class BaseActivity : AppCompatActivity() {

    lateinit var networkObserver: NetworkObserver

    lateinit var appService: ApiService

    protected val authRepository: AuthRepository = AuthRepository()

    protected val compositeDisposable = CompositeDisposable()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        networkObserver = NetworkObserver(application)
        appService = AppService.createService(this)
    }


    override fun onDestroy() {
        compositeDisposable.clear()
        super.onDestroy()
    }
}