package com.narola.kotlinmvvmframework.ui.register.view

import android.content.Context
import android.content.Intent
import android.os.Bundle
import com.narola.kotlinmvvmframework.R
import com.narola.kotlinmvvmframework.base.BaseActivity
import com.narola.kotlinmvvmframework.base.extentions.getViewModel
import com.narola.kotlinmvvmframework.base.rxjava.autoDispose
import com.narola.kotlinmvvmframework.base.rxjava.throttleClicks
import com.narola.kotlinmvvmframework.ui.register.viewmodel.RegisterViewModel
import kotlinx.android.synthetic.main.activity_register.*

class RegisterActivity : BaseActivity() {


    companion object {
        fun getIntent(context: Context): Intent {
            val intent = Intent(context, RegisterActivity::class.java)
            return intent
        }
    }

    private lateinit var viewModel: RegisterViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)
        viewModel = getViewModel { RegisterViewModel(authRepository) }

        registerButton.throttleClicks()
                .subscribe {
                    val name = registerName.text.toString()
                    val email = registerEmail.text.toString()
                    val password = registerPassword.text.toString()
                    if (name.isNotEmpty() && email.isNotEmpty() && password.isNotEmpty()) {
                        viewModel.registerAccount(name, email, password)
                    }
                }.autoDispose(compositeDisposable)
    }

}