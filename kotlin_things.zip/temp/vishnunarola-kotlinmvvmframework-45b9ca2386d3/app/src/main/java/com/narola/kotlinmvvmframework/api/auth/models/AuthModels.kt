package com.narola.kotlinmvvmframework.api.auth.models

/**
 * Created by Narola on 2019-06-07.
 */

data class LoginResult(val isSuccess: Boolean = false, val user: User? = null, val error: Throwable? = null)

data class User(val userId: String, val username: String?, val email: String?)

data class RegisterResult(val isSuccess: Boolean,
                          val user: User?,
                          val error: Throwable?)