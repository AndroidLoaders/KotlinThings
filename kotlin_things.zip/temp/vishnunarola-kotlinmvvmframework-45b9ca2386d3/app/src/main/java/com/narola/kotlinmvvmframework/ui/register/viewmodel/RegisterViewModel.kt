package com.narola.kotlinmvvmframework.ui.register.viewmodel

import androidx.lifecycle.MutableLiveData
import com.narola.kotlinmvvmframework.api.auth.AuthRepository
import com.narola.kotlinmvvmframework.base.BaseViewModel
import com.narola.kotlinmvvmframework.base.rxjava.autoDispose
import com.narola.kotlinmvvmframework.api.auth.models.RegisterResult

class RegisterViewModel(private val authRepository: AuthRepository) : BaseViewModel() {
    val registerResultObserver: MutableLiveData<RegisterResult> = MutableLiveData()

    fun registerAccount(name: String, email: String, password: String) {
        authRepository.register(name, email, password)
                .doOnSubscribe { isLoading.postValue(true) }
                .doOnDispose { isLoading.postValue(false) }
                .doOnSuccess { isLoading.postValue(false) }
                .doOnError { isLoading.postValue(false) }
                .subscribe({ registerResult ->
                    registerResultObserver.postValue(registerResult)
                }, { error ->
                    isError.postValue(error)
                    registerResultObserver.postValue(RegisterResult(isSuccess = false, error = error, user = null))
                }).autoDispose(compositeDisposable)
    }
}