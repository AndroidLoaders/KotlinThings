package com.narola.kotlinmvvmframework.ui.main.viewmodel

import androidx.lifecycle.MutableLiveData
import com.narola.kotlinmvvmframework.api.service.ApiService
import com.narola.kotlinmvvmframework.base.BaseViewModel
import com.narola.kotlinmvvmframework.base.rxjava.autoDispose
import com.narola.kotlinmvvmframework.ui.main.model.Post
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers

class MainViewModel(private val apiService: ApiService) : BaseViewModel() {

    val launchLoginActivity: MutableLiveData<Unit> = MutableLiveData()
    val countriesLiveData: MutableLiveData<List<Post>> = MutableLiveData()
    val postClicksSubject: MutableLiveData<Post> = MutableLiveData()

    fun checkUser() {

    }

    fun getCountries() {
        apiService.getCountry()
                .doOnSubscribe {
                    isLoading.postValue(true)
                }
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe({ countries->
                    countriesLiveData.value = countries
                }, { error ->
                    isError.value = error
                }).autoDispose(compositeDisposable)
    }

    fun onClickCountry(post: Post) {
        postClicksSubject.value = post
    }


}