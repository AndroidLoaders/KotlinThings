package com.narola.kotlinmvvmframework.ui.main.view

import androidx.recyclerview.widget.RecyclerView
import android.view.View
import android.view.ViewGroup
import com.narola.kotlinmvvmframework.ui.main.model.Post
import io.reactivex.Observable
import io.reactivex.subjects.PublishSubject

/**
 * Created by Narola on 26/10/18.
 */

class PostAdapter : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    private val itemClickSubject: PublishSubject<Post> = PublishSubject.create()
    var itemClick: Observable<Post> = itemClickSubject.hide()

    private val adapterItems: MutableList<AdapterItem> = mutableListOf()

    var posts: List<Post> = listOf()
        set(value) {
            field = value
            updateAdapterItem()
        }

    private fun updateAdapterItem() {
        val adapterItems = mutableListOf<AdapterItem>()
        for (i in 0 until posts.size) {
            if (i % 2 == 0) {
                adapterItems.add(AdapterItem.ItemRight(posts[i]))
            } else {
                adapterItems.add(AdapterItem.ItemLeft(posts[i]))
            }
        }
        this.adapterItems.addAll(adapterItems)
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(viewGroup: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return when (Type.values()[viewType]) {
            Type.ITEM_LEFT -> {
                PostViewHolder(LeftPostView(viewGroup.context).apply {
                    itemClick.subscribe { country ->
                        itemClickSubject.onNext(country)
                    }
                })
            }
            Type.ITEM_RIGHT -> PostViewHolder(RightPostView(viewGroup.context).apply {
                itemClick.subscribe { country ->
                    itemClickSubject.onNext(country)
                }
            })
        }

    }

    override fun getItemCount(): Int {
        return adapterItems.size
    }

    override fun getItemViewType(position: Int): Int {
        return adapterItems[position].type
    }

    override fun onBindViewHolder(viewHolder: RecyclerView.ViewHolder, position: Int) {
        when (val adapterItem = adapterItems[position]) {
            is AdapterItem.ItemLeft -> {
                (viewHolder.itemView as LeftPostView).bind(adapterItem.post)
            }
            is AdapterItem.ItemRight ->{
                (viewHolder.itemView as RightPostView).bind(adapterItem.post)
            }
        }
    }

    private class PostViewHolder(view: View) : RecyclerView.ViewHolder(view)

    sealed class AdapterItem(val type: Int) {
        data class ItemLeft(val post: Post) : AdapterItem(Type.ITEM_LEFT.ordinal)
        data class ItemRight(val post: Post) : AdapterItem(Type.ITEM_RIGHT.ordinal)
    }

    enum class Type {
        ITEM_LEFT, ITEM_RIGHT
    }

}