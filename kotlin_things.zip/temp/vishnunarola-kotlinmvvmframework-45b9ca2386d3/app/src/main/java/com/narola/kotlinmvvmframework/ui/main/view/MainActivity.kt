package com.narola.kotlinmvvmframework.ui.main.view

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.LinearLayoutManager
import com.narola.kotlinmvvmframework.R
import com.narola.kotlinmvvmframework.base.BaseActivity
import com.narola.kotlinmvvmframework.base.extentions.getViewModel
import com.narola.kotlinmvvmframework.ui.login.view.LoginActivity
import com.narola.kotlinmvvmframework.ui.main.viewmodel.MainViewModel
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : BaseActivity() {

    companion object {
        fun getIntent(context: Context): Intent {
            return Intent(context, MainActivity::class.java)
        }
    }

    private lateinit var viewModel: MainViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        viewModel = getViewModel {
            MainViewModel(
                    appService
            )
        }
        val countryAdapter = PostAdapter().apply {
            itemClick.subscribe { country ->
                viewModel.onClickCountry(country)
            }
        }
        mainRecyclerView.layoutManager = LinearLayoutManager(this)
        mainRecyclerView.adapter = countryAdapter
        viewModel.launchLoginActivity.observe(this, Observer {
            startActivity(LoginActivity.getIntent(this))
            finish()
        })
        viewModel.countriesLiveData.observe(this, Observer { listOfCountry ->
            listOfCountry?.let {
                countryAdapter.posts = it
            }
        })
        viewModel.postClicksSubject.observe(this, Observer { post ->
            post?.let {
                Toast.makeText(this, "Post clicked ${post.title}", Toast.LENGTH_LONG).show()
            }
        })
        viewModel.getCountries()
    }

}
