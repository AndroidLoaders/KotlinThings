package com.narola.kotlinmvvmframework.ui.login.viewmodel

import androidx.lifecycle.MutableLiveData
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import com.narola.kotlinmvvmframework.api.auth.AuthRepository
import com.narola.kotlinmvvmframework.api.auth.models.LoginResult
import com.narola.kotlinmvvmframework.base.BaseViewModel
import com.narola.kotlinmvvmframework.base.rxjava.autoDispose

class LoginViewModel(private val authRepository: AuthRepository) : BaseViewModel() {

    val loginResultObserver: MutableLiveData<LoginResult> = MutableLiveData()

    fun loginWithEmailPassword(email: String, password: String) {
        authRepository.login(email, password)
                .subscribe({
                    loginResultObserver.postValue(it)
                }, {
                    loginResultObserver.postValue(LoginResult(isSuccess = false, error = it))
                }).autoDispose(compositeDisposable)
    }

    fun loginWithGoogle(googleSignInAccount: GoogleSignInAccount) {
        authRepository.firebaseAuthWithGoogle(googleSignInAccount)
                .subscribe({
                    loginResultObserver.postValue(it)
                }, {
                    loginResultObserver.postValue(LoginResult(isSuccess = false, error = it))
                }).autoDispose(compositeDisposable)
    }

}