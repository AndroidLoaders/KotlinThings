package com.narola.kotlinmvvmframework.ui.main.view

import android.content.Context
import androidx.constraintlayout.widget.ConstraintLayout
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.bumptech.glide.load.resource.bitmap.RoundedCorners
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions
import com.bumptech.glide.request.RequestOptions
import com.narola.kotlinmvvmframework.R
import com.narola.kotlinmvvmframework.base.glide.GlideApp
import com.narola.kotlinmvvmframework.base.rxjava.autoDispose
import com.narola.kotlinmvvmframework.base.rxjava.throttleClicks
import com.narola.kotlinmvvmframework.ui.main.model.Post
import io.reactivex.Observable
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.subjects.PublishSubject
import kotlinx.android.synthetic.main.view_left_post.view.*

/**
 * Created by Narola on 26/10/18.
 */
class RightPostView(context: Context) : FrameLayout(context) {

    private val itemClickSubject: PublishSubject<Post> = PublishSubject.create()
    var itemClick: Observable<Post> = itemClickSubject.hide()

    private val compositeDisposable = CompositeDisposable()

    init {
        layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        View.inflate(context, R.layout.view_right_post, this)
    }

    fun bind(post: Post) {
        GlideApp.with(this)
                .load(post.thumbnailUrl)
                .transition(DrawableTransitionOptions.withCrossFade())
                .apply(RequestOptions.bitmapTransform(RoundedCorners(context.resources.getDimensionPixelSize(R.dimen.corner_radius))))
                .diskCacheStrategy(DiskCacheStrategy.ALL)
                .into(albumImage)
        albumTitle.text = post.title
        throttleClicks().subscribe {
            itemClickSubject.onNext(post)
        }.autoDispose(compositeDisposable)
    }


}