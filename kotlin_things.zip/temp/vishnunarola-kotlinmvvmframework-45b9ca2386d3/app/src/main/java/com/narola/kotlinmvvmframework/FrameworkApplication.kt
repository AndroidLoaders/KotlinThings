package com.narola.kotlinmvvmframework

import androidx.multidex.MultiDexApplication
import com.narola.kotlinmvvmframework.base.network.installTls12
import com.narola.kotlinmvvmframework.base.view.ActivityManager

/**
 * Created by Narola on 25/08/18.
 */
class FrameworkApplication : MultiDexApplication() {


    override fun onCreate() {
        super.onCreate()
        ActivityManager.getInstance().init(this)
        installTls12()
    }


}