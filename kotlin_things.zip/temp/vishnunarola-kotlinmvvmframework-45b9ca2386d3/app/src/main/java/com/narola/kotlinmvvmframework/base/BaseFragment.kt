package com.narola.kotlinmvvmframework.base

import android.app.Activity
import android.content.Context
import android.os.Bundle
import androidx.fragment.app.Fragment
import com.narola.kotlinmvvmframework.api.service.ApiService
import com.narola.kotlinmvvmframework.api.service.AppService
import com.narola.kotlinmvvmframework.base.network.NetworkObserver
import io.reactivex.disposables.CompositeDisposable

class BaseFragment : Fragment() {

    protected val compositeDisposable = CompositeDisposable()

    lateinit var activity: Activity
    lateinit var networkObserver: NetworkObserver
    lateinit var appService: ApiService

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        networkObserver = NetworkObserver(activity.application)
        appService = AppService.createService(activity)
    }

    override fun onAttach(context: Context?) {
        super.onAttach(context)
        context?.let {
            activity = (context as Activity)
        }
    }

    override fun onDestroy() {
        compositeDisposable.clear()
        super.onDestroy()
    }
}