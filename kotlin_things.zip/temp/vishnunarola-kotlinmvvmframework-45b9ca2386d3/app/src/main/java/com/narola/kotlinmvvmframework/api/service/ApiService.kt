package com.narola.kotlinmvvmframework.api.service

import com.narola.kotlinmvvmframework.ui.main.model.Post
import io.reactivex.Single
import retrofit2.http.GET

/**
 * Created by Narola on 25/08/18.
 */
interface ApiService {

    @GET("/photos")
    fun getCountry(): Single<List<Post>>
}