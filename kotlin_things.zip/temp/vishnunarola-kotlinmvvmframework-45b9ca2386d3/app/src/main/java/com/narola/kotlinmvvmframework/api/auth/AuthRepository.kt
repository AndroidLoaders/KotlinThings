package com.narola.kotlinmvvmframework.api.auth

import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import com.google.android.gms.tasks.Task
import com.google.firebase.auth.*
import com.narola.kotlinmvvmframework.api.auth.models.LoginResult
import com.narola.kotlinmvvmframework.api.auth.models.RegisterResult
import com.narola.kotlinmvvmframework.api.auth.models.User
import io.reactivex.Single
import io.reactivex.SingleEmitter

/**
 * Created by Narola on 2019-06-07.
 */
class AuthRepository {

    private val auth: FirebaseAuth by lazy {
        FirebaseAuth.getInstance()
    }


    fun login(username: String, password: String): Single<LoginResult> {
        auth.currentUser?.let {
            if (!it.isAnonymous) {
                auth.signOut()
            }
        }

        return Single.create<LoginResult> { emitter ->
            auth.currentUser?.let {
                if (it.isAnonymous) {
                    val credential = EmailAuthProvider.getCredential(username, password)
                    loginWithCredential(credential)
                    return@create
                }
            }

            auth.signInWithEmailAndPassword(username, password)
                    .addOnCompleteListener { task ->
                        onCompleteLogin(task, emitter)
                    }
        }
    }

    fun loginWithCredential(credential: AuthCredential): Single<LoginResult> {
        auth.currentUser?.let {
            if (!it.isAnonymous) {
                auth.signOut()
            }
        }
        return Single.create<LoginResult> { emitter ->
            auth.currentUser?.let {
                if (it.isAnonymous) {
                    it.linkWithCredential(credential)
                            .addOnCompleteListener { task ->
                                onCompleteLogin(task, emitter)
                            }
                    return@create
                }
            }

            auth.signInWithCredential(credential)
                    .addOnCompleteListener { task ->
                        onCompleteLogin(task, emitter)
                    }
        }
    }

    private fun onCompleteLogin(task: Task<AuthResult>, emitter: SingleEmitter<LoginResult>) {
        if (task.isSuccessful) {
            // Sign in success
            FirebaseAuth.getInstance().currentUser?.let { currentUser ->

                emitter.onSuccess(LoginResult(true, currentUser.toUser()))
            } ?: run {
                emitter.onSuccess(LoginResult(false))
            }
        } else {
            // If sign in fails
            task.exception?.let {
                emitter.onSuccess(LoginResult(isSuccess = false, error = it))
            } ?: run {
                emitter.onSuccess(LoginResult(isSuccess = false))
            }
        }
    }


    fun register(fullName: String, email: String, password: String): Single<RegisterResult> {
        return Single.create<RegisterResult> { emitter ->
            auth.createUserWithEmailAndPassword(email, password)
                    .addOnCompleteListener { task ->
                        var registerResult: RegisterResult
                        if (task.isSuccessful) {
                            val user = auth.currentUser
                            user?.let { authUser ->
                                val updateUserProfileChangeRequest = UserProfileChangeRequest.Builder()
                                        .setDisplayName(fullName)
                                        .build()
                                authUser.updateProfile(updateUserProfileChangeRequest)
                                        .addOnCompleteListener {
                                            if (it.isSuccessful) {
                                                registerResult = RegisterResult(true, authUser.toUser(), error = null)
                                                emitter.onSuccess(registerResult)
                                            } else {
                                                registerResult = RegisterResult(false, authUser.toUser(), error = it.exception)
                                                emitter.onSuccess(registerResult)
                                            }
                                        }
                            }
                        } else {
                            emitter.onError(Throwable(task.exception?.message))
                        }
                    }
        }
    }

    fun firebaseAuthWithGoogle(acct: GoogleSignInAccount):Single<LoginResult> {
        val credential = GoogleAuthProvider.getCredential(acct.idToken, null)
        return loginWithCredential(credential)
    }


    private fun FirebaseUser.toUser(): User {
        return User(this.uid, this.displayName, this.email)
    }
}