package com.app.tagglifedatingapp.custom

import android.annotation.SuppressLint
import android.os.Handler
import android.view.MotionEvent
import android.view.View

/**
 * @param initialInterval : The interval after first click event
 * @param normalInterval : The interval after second and subsequent click
 * events
 * @param clickListener : The OnClickListener, that will be called
 * periodically
 */
open class RepeatListener(private var clickListener: View.OnClickListener?) : View.OnTouchListener {

    private val handler = Handler()
    private var touchedView: View? = null

    private var normalInterval: Int = 400
    private var initialInterval: Int = 150

    private val handlerRunnable = object : Runnable {
        override fun run() {
            if (touchedView!!.isEnabled) {
                handler.postDelayed(this, normalInterval.toLong())
                clickListener?.onClick(touchedView)
            } else {
                // if the view was disabled by the clickListener, remove the callback
                handler.removeCallbacks(this)
                touchedView!!.isPressed = false
                touchedView = null
            }
        }
    }

    constructor(initialInterval: Int, normalInterval: Int, clickListener: View.OnClickListener?) : this(clickListener) {
        requireNotNull(clickListener) { "null runnable" }
        require(!(initialInterval < 0 || normalInterval < 0)) { "negative interval" }
        /*if (clickListener == null) throw IllegalArgumentException("null runnable")
        if (initialInterval < 0 || normalInterval < 0) throw IllegalArgumentException("negative interval")*/

        this.initialInterval = initialInterval
        this.normalInterval = normalInterval
        this.clickListener = clickListener
    }

    init {
        requireNotNull(clickListener) { "null runnable" }
        // if (clickListener == null) throw IllegalArgumentException("null runnable")
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouch(view: View, motionEvent: MotionEvent): Boolean {
        when (motionEvent.action) {
            MotionEvent.ACTION_DOWN -> {
                handler.removeCallbacks(handlerRunnable)
                handler.postDelayed(handlerRunnable, initialInterval.toLong())
                touchedView = view
                touchedView!!.isPressed = true
                clickListener?.onClick(view)
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                handler.removeCallbacks(handlerRunnable)
                touchedView!!.isPressed = false
                touchedView = null
                return true
            }
        }

        return false
    }

}