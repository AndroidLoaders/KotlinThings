package com.app.skatetoski.networkadapter.api;

import com.app.skatetoski.callbacks.ApiResponse;
import com.app.skatetoski.model.LearnRepository;
import com.app.skatetoski.model.RefreshTokenRepository;
import com.app.skatetoski.model.TrainRepository;
import com.app.skatetoski.model.UpdateRefreshToken;
import com.app.skatetoski.model.UserRepository;
import com.google.gson.JsonObject;

public interface ApiInterceptor {

    void refreshToken(JsonObject parameters, ApiResponse<RefreshTokenRepository> apiResponse);

    void updateRefreshToken(JsonObject parameters, ApiResponse<UpdateRefreshToken> apiResponse);

    void registerUser(JsonObject parameters, ApiResponse<UserRepository> apiResponse);

    void loginUser(JsonObject parameters, ApiResponse<UserRepository> apiResponse);

    void changePassword(JsonObject parameters, ApiResponse<UpdateRefreshToken> apiResponse);

    void getLearnList(JsonObject parameters, ApiResponse<LearnRepository> apiResponse);

    void checkUncheckLearnItem(JsonObject parameters, ApiResponse<LearnRepository> apiResponse);

    void getTrainList(JsonObject parameters, ApiResponse<TrainRepository> apiResponse);

    void checkTrainList(JsonObject parameters, ApiResponse<TrainRepository> apiResponse);
}
