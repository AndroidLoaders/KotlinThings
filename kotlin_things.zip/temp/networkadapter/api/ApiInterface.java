package com.app.skatetoski.networkadapter.api;

import com.app.skatetoski.model.LearnRepository;
import com.app.skatetoski.model.RefreshTokenRepository;
import com.app.skatetoski.model.TrainRepository;
import com.app.skatetoski.model.UpdateRefreshToken;
import com.app.skatetoski.model.UserRepository;
import com.app.skatetoski.networkadapter.apiconstants.ApiProvider;
import com.google.gson.JsonObject;

import okhttp3.MultipartBody;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.Part;

public interface ApiInterface {

    @POST(ApiProvider.ApiRefreshToken)
    Call<RefreshTokenRepository> getRefreshToken(@Body JsonObject parameters);

    @POST(ApiProvider.ApiUpdateRefreshToken)
    Call<UpdateRefreshToken> updateRefreshToken(@Body JsonObject parameters);

    @POST(ApiProvider.ApiRegistration)
    Call<UserRepository> registerUser(@Body JsonObject parameters);

    @POST(ApiProvider.ApiLogin)
    Call<UserRepository> loginUser(@Body JsonObject parameters);

    @POST(ApiProvider.ApiChangePassword)
    Call<UpdateRefreshToken> changePassword(@Body JsonObject parameters);
    //<ResponseClass extends ApiStatus> Call<ResponseClass> getUsersList(@Body JsonObject parameters);

    @POST(ApiProvider.ApiGetLearnList)
    Call<LearnRepository> getLearnList(@Body JsonObject parameters);

    @POST(ApiProvider.ApiCheckUncheckLearnItem)
    Call<LearnRepository> checkUncheckLearnItem(@Body JsonObject parameters);
    //<ResponseClass extends ApiStatus> Call<ResponseClass> checkUncheckLearnItem(@Body JsonObject parameters);

    @POST(ApiProvider.ApiGetTrainList)
    Call<TrainRepository> getTrainList(@Body JsonObject parameters);

    @POST(ApiProvider.ApiMultipleCheckTrainList)
    Call<TrainRepository> checkMultipleTrainList(@Body JsonObject parameters);
}
