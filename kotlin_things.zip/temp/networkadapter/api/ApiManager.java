package com.app.skatetoski.networkadapter.api;

import android.support.annotation.NonNull;

import com.app.skatetoski.callbacks.ApiResponse;
import com.app.skatetoski.model.LearnRepository;
import com.app.skatetoski.model.RefreshTokenRepository;
import com.app.skatetoski.model.TrainRepository;
import com.app.skatetoski.model.UpdateRefreshToken;
import com.app.skatetoski.model.UserRepository;
import com.app.skatetoski.networkadapter.apiconstants.ApiProvider;
import com.app.skatetoski.networkadapter.retrofit.RetrofitClient;
import com.google.gson.JsonObject;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ApiManager implements ApiInterceptor {

    private ApiInterface apiInterface;

    public ApiManager() {
        apiInterface = new RetrofitClient().getApiClient();
    }

    @Override
    public void refreshToken(JsonObject parameters, ApiResponse<RefreshTokenRepository> apiResponse) {
        apiInterface.getRefreshToken(parameters).enqueue(new Callback<RefreshTokenRepository>() {
            @Override
            public void onResponse(@NonNull Call<RefreshTokenRepository> call, @NonNull Response<RefreshTokenRepository> response) {
                onNext("", response, apiResponse);
            }

            @Override
            public void onFailure(@NonNull Call<RefreshTokenRepository> call, @NonNull Throwable throwable) {
                apiResponse.onFailed("", throwable);
                call.cancel();
            }
        });
    }

    @Override
    public void updateRefreshToken(JsonObject parameters, ApiResponse<UpdateRefreshToken> apiResponse) {
        apiInterface.updateRefreshToken(parameters).enqueue(new Callback<UpdateRefreshToken>() {
            @Override
            public void onResponse(@NonNull Call<UpdateRefreshToken> call, @NonNull Response<UpdateRefreshToken> response) {
                onNext("", response, apiResponse);
            }

            @Override
            public void onFailure(@NonNull Call<UpdateRefreshToken> call, @NonNull Throwable throwable) {
                apiResponse.onFailed("", throwable);
                call.cancel();
            }
        });
    }

    @Override
    public void registerUser(JsonObject parameters, ApiResponse<UserRepository> apiResponse) {
        apiInterface.registerUser(parameters).enqueue(new Callback<UserRepository>() {
            @Override
            public void onResponse(@NonNull Call<UserRepository> call, @NonNull Response<UserRepository> response) {
                onNext("", response, apiResponse);
            }

            @Override
            public void onFailure(@NonNull Call<UserRepository> call, @NonNull Throwable throwable) {
                apiResponse.onFailed("", throwable);
                call.cancel();
            }
        });
    }

    @Override
    public void loginUser(JsonObject parameters, ApiResponse<UserRepository> apiResponse) {
        apiInterface.loginUser(parameters).enqueue(new Callback<UserRepository>() {
            @Override
            public void onResponse(@NonNull Call<UserRepository> call, @NonNull Response<UserRepository> response) {
                onNext("", response, apiResponse);
            }

            @Override
            public void onFailure(@NonNull Call<UserRepository> call, @NonNull Throwable throwable) {
                apiResponse.onFailed("", throwable);
                call.cancel();
            }
        });
    }

    @Override
    public void changePassword(JsonObject parameters, ApiResponse<UpdateRefreshToken> apiResponse) {
        apiInterface.changePassword(parameters).enqueue(new Callback<UpdateRefreshToken>() {
            @Override
            public void onResponse(@NonNull Call<UpdateRefreshToken> call, @NonNull Response<UpdateRefreshToken> response) {
                onNext("", response, apiResponse);
            }

            @Override
            public void onFailure(@NonNull Call<UpdateRefreshToken> call, @NonNull Throwable throwable) {
                apiResponse.onFailed("", throwable);
                call.cancel();
            }
        });
    }

    @Override
    public void getLearnList(JsonObject parameters, ApiResponse<LearnRepository> apiResponse) {
        apiInterface.getLearnList(parameters).enqueue(new Callback<LearnRepository>() {
            @Override
            public void onResponse(@NonNull Call<LearnRepository> call, @NonNull Response<LearnRepository> response) {
                onNext(ApiProvider.ApiGetLearnList, response, apiResponse);
            }

            @Override
            public void onFailure(@NonNull Call<LearnRepository> call, @NonNull Throwable throwable) {
                apiResponse.onFailed(ApiProvider.ApiGetLearnList, throwable);
                call.cancel();
            }
        });
    }

    @Override
    public void checkUncheckLearnItem(JsonObject parameters, ApiResponse<LearnRepository> apiResponse) {
        apiInterface.checkUncheckLearnItem(parameters).enqueue(new Callback<LearnRepository>() {
            @Override
            public void onResponse(@NonNull Call<LearnRepository> call, @NonNull Response<LearnRepository> response) {
                onNext(ApiProvider.ApiCheckUncheckLearnItem, response, apiResponse);
            }

            @Override
            public void onFailure(@NonNull Call<LearnRepository> call, @NonNull Throwable throwable) {
                apiResponse.onFailed(ApiProvider.ApiCheckUncheckLearnItem, throwable);
                call.cancel();
            }
        });
    }

    @Override
    public void getTrainList(JsonObject parameters, ApiResponse<TrainRepository> apiResponse) {
        apiInterface.getTrainList(parameters).enqueue(new Callback<TrainRepository>() {
            @Override
            public void onResponse(@NonNull Call<TrainRepository> call, @NonNull Response<TrainRepository> response) {
                onNext(ApiProvider.ApiGetTrainList, response, apiResponse);
            }

            @Override
            public void onFailure(@NonNull Call<TrainRepository> call, @NonNull Throwable throwable) {
                apiResponse.onFailed(ApiProvider.ApiGetTrainList, throwable);
                call.cancel();
            }
        });
    }

    @Override
    public void checkTrainList(JsonObject parameters, ApiResponse<TrainRepository> apiResponse) {
        apiInterface.checkMultipleTrainList(parameters).enqueue(new Callback<TrainRepository>() {
            @Override
            public void onResponse(@NonNull Call<TrainRepository> call, @NonNull Response<TrainRepository> response) {
                onNext(ApiProvider.ApiMultipleCheckTrainList, response, apiResponse);
            }

            @Override
            public void onFailure(@NonNull Call<TrainRepository> call, @NonNull Throwable throwable) {
                apiResponse.onFailed(ApiProvider.ApiMultipleCheckTrainList, throwable);
                call.cancel();
            }
        });
    }

    private <ResponseClass extends ApiStatus> void onNext(String apiTag, @NonNull Response<ResponseClass> response, ApiResponse<ResponseClass> apiResponse) {
        if (response.isSuccessful() && (response.body() != null))
            apiResponse.onSuccess(apiTag, response.body());
        else apiResponse.onFailed(apiTag, response.message());
    }
}
