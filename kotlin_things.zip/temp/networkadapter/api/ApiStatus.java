package com.app.skatetoski.networkadapter.api;

public abstract class ApiStatus {

    public int status = 0;
    public String message = "";

    private String userToken = "";

    public String getUserToken() {
        return (userToken != null) ? userToken : "";
    }
}
