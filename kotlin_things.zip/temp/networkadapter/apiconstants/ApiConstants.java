package com.app.skatetoski.networkadapter.apiconstants;

public final class ApiConstants {

    /**
    * Local : http://clientapp.narola.online/pg/SkateToSki/SkateToSkiApp.php?Service=Login
    * Live : http://165.227.71.63/SkateToSki/SkateToSkiApp.php?Service=Login
    * */

    public static final String BASE_URL = "http://165.227.71.63/SkateToSki/";

    public static final String SECRET_KEY = "secret_key";
    public static final String DEVICE_TOKEN = "device_token";
    public static final String DEVICE_TYPE = "device_type";

    public static final String DEVICE_TYPE_ANDROID = "2";

    // ApiRefreshToken
    public static final String ADMIN_CONFIG = "adminConfig";
    public static final String ACCESS_KEY = "access_key";
    public static final String ACCESS_VALUE = "nousername";

    // ApiProvider.ApiUpdateRefreshToken
    public static final String GU_ID = "guid";

    // ApiProvider.ApiRegistration
    public static final String USER = "User";
    public static final String USER_NAME = "name";
    public static final String EMAIL_ID = "email_id";
    public static final String USER_ID = "user_id";
    public static final String PASSWORD = "password";

    // ApiProvider.ApiGetLearnList
    public static final String LEARN_ID = "learn_id";
    public static final String PARENT_ID = "parent_id";
    public static final String LEARN_LIST = "learn_list";
    public static final String IS_CHECK = "is_check";
    public static final String PROGRESS_PERCENT = "progress_percent";

    // ApiProvider.ApiGetTrainList
    public static final String TRAIN_LIST = "train_list";
    public static final String TRAIN_ID = "train_ids";
    public static final String TITLE = "title";
    public static final String IMAGE = "image";
    public static final String LIST_TYPE = "list_type";

    // ApiProvider.ApiChangePassword
    public static final String NEW_PASSWORD = "newpassword";
    public static final String OLD_PASSWORD = "oldpassword";
}
