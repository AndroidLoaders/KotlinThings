package com.app.skatetoski.networkadapter.apiconstants;

public final class ApiProvider {

    private static final String API_EXTENSION = "SkateToSkiApp.php?Service=";

    private static final String API_HOST = ApiConstants.BASE_URL + API_EXTENSION;

    private static final String REFRESH_TOKEN = "RefreshToken";
    public static final String ApiRefreshToken = API_HOST + REFRESH_TOKEN;

    private static final String UPDATE_REFRESH_TOKEN = "UpdateTokenForUser";
    public static final String ApiUpdateRefreshToken = API_HOST + UPDATE_REFRESH_TOKEN;

    private static final String REGISTRATION = "Register";
    public static final String ApiRegistration = API_HOST + REGISTRATION;

    private static final String LOGIN = "Login";
    public static final String ApiLogin = API_HOST + LOGIN;

    private static final String CHANGE_PASSWORD = "ChangePassword";
    public static final String ApiChangePassword = API_HOST + CHANGE_PASSWORD;

    private static final String GET_LEARN_LIST = "GetLearnList";
    public static final String ApiGetLearnList = API_HOST + GET_LEARN_LIST;

    private static final String CHECK_UNCHECK_ITEM = "CheckLearnList";
    public static final String ApiCheckUncheckLearnItem = API_HOST + CHECK_UNCHECK_ITEM;

    private static final String GET_TRAIN_LIST = "GetTrainList";
    public static final String ApiGetTrainList = API_HOST + GET_TRAIN_LIST;

    private static final String CHECK_MULTIPLE_TRAIN_LIST = "CheckMultipleTrainList";
    public static final String ApiMultipleCheckTrainList = API_HOST + CHECK_MULTIPLE_TRAIN_LIST;
}