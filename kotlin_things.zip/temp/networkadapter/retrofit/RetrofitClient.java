package com.app.skatetoski.networkadapter.retrofit;

import com.app.skatetoski.networkadapter.api.ApiInterface;
import com.app.skatetoski.networkadapter.apiconstants.ApiConstants;
import com.google.gson.GsonBuilder;

import java.util.concurrent.TimeUnit;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class RetrofitClient {

    private static final long REQUEST_TIMEOUT = 30L;

    private ApiInterface apiInterface;
    private OkHttpClient httpClient;

    private void initOkHttp() {
        HttpLoggingInterceptor interceptor = new HttpLoggingInterceptor();
        interceptor.setLevel(HttpLoggingInterceptor.Level.BODY);

        OkHttpClient.Builder httpBuilder = new OkHttpClient().newBuilder()
                .connectTimeout(REQUEST_TIMEOUT, TimeUnit.SECONDS)
                .readTimeout(REQUEST_TIMEOUT, TimeUnit.SECONDS)
                .writeTimeout(REQUEST_TIMEOUT, TimeUnit.SECONDS)
                .addInterceptor(interceptor).addInterceptor(chain -> {
                    Request original = chain.request();
                    Request request = original.newBuilder()
                            .addHeader("Accept", "application/json")
                            .addHeader("Request-Type", "Android")
                            .addHeader("Content-Type", "application/json")
                            .addHeader("User-Agent", "Android")
                            .build();
                    return chain.proceed(request);
                });

        httpClient = httpBuilder.build();
    }

    public ApiInterface getApiClient() {
        if (httpClient == null) initOkHttp();

        if (apiInterface == null) {
            apiInterface = new Retrofit.Builder().baseUrl(ApiConstants.BASE_URL).client(httpClient)
                    .addConverterFactory(GsonConverterFactory.create(new GsonBuilder().setLenient().create()))
                    .build().create(ApiInterface.class);
        }

        return apiInterface;
    }
}