package com.app.tagglifedatingapp.database.manager

import com.app.tagglifedatingapp.TaggLifeApplication
import com.app.tagglifedatingapp.database.configuration.RealmConfig
import com.app.tagglifedatingapp.database.constants.RealmConstants
import com.app.tagglifedatingapp.models.ChatMessages
import com.app.tagglifedatingapp.models.ChatUser
import com.app.tagglifedatingapp.networkadapter.apiconstants.ApiConstants
import com.app.tagglifedatingapp.socket.io.socketconstants.SocketConstants
import com.app.tagglifedatingapp.utility.AppConstants
import com.app.tagglifedatingapp.utility.Logs
import io.realm.Realm
import io.realm.RealmResults
import io.realm.Sort
import io.realm.kotlin.where
import org.json.JSONObject

class RealmManager : RealmInteractor {

    private val preference = TaggLifeApplication.getInstance().getPreference()

    override val realm: Realm
        get() = Realm.getInstance(RealmConfig.getRealmConfig())

    @Throws(Exception::class)
    override fun cancelTransaction() = if (realm.isInTransaction) realm.cancelTransaction() else {
    }

    @Throws(Exception::class)
    override fun removeAllChatUsers() {
        realm.beginTransaction()
        realm.where<ChatUser>().findAll().deleteAllFromRealm()
        realm.commitTransaction()
    }

    @Throws(Exception::class)
    override fun saveConversations(chatUserList: MutableList<ChatUser>) {
        realm.beginTransaction()
        realm.copyToRealmOrUpdate(chatUserList)
        realm.commitTransaction()
    }

    @Throws(Exception::class)
    override fun saveConversation(jsonObject: JSONObject) {
        val chatUser = ChatUser()
        chatUser.setUserId(jsonObject.optInt(ApiConstants.SENDER_ID, 0))
        chatUser.setConversionId(jsonObject.optInt(ApiConstants.CONVERSION_ID, 0))
        chatUser.setFirstName(jsonObject.optString(ApiConstants.OTHER_USER_FIRST_NAME, ""))
        chatUser.setLastName(jsonObject.optString(ApiConstants.OTHER_USER_LAST_NAME, ""))
        chatUser.setProfilePic(jsonObject.optString(ApiConstants.OTHER_USER_PRIFILE_PIC, ""))
        chatUser.setLastMessageDate(jsonObject.optString(ApiConstants.CREATED_DATE, ""))
        realm.beginTransaction()
        realm.copyToRealmOrUpdate(chatUser)
        //realm.createOrUpdateObjectFromJson(ChatUser::class.java, jsonObject)
        realm.commitTransaction()
    }

    @Throws(Exception::class)
    override fun getChatConversions(): RealmResults<ChatUser> = realm.where<ChatUser>().findAll()

    @Throws(Exception::class)
    override fun getChatConversion(conversionId: Int): ChatUser? =
        realm.where<ChatUser>().equalTo(RealmConstants.CONVERSION_ID, conversionId).findFirst()

    @Throws(Exception::class)
    override fun readAllMessages(otherUserId: Int) {
        val unreadMessages = getUnreadMessages(otherUserId)
        if (unreadMessages != null && unreadMessages.size > 0) {
            realm.beginTransaction()
            unreadMessages.forEach { it.setMessageRead(true) }
            realm.commitTransaction()
        }
    }

    @Throws(Exception::class)
    override fun getUnreadMessages(otherUserId: Int): RealmResults<ChatMessages>? =
        realm.where<ChatMessages>().equalTo(RealmConstants.IS_READ_MESSAGE, false)
            .equalTo(RealmConstants.SENDER_ID, otherUserId).findAll()

    @Throws(Exception::class)
    override fun getUnreadMessagesForAllUsers(): MutableMap<String, MutableList<ChatMessages>> {
        val messagesMap = mutableMapOf<String, MutableList<ChatMessages>>()
        // TODO : Sort chat users according to last message received time
        getChatConversions().sort(RealmConstants.LAST_MESSAGE_ID, Sort.ASCENDING).forEach {
            val messagesList = getUnreadMessages(it.getUserId())
            if ((messagesList != null) && (messagesList.size > 0)) {
                messagesMap[it.getUserName().plus("_").plus(it.getUserId())] =
                    realm.copyFromRealm(
                        messagesList.sort(RealmConstants.CREATED_DATE, Sort.DESCENDING)
                    )
            }
        }
        return messagesMap
    }

    @Throws(Exception::class)
    override fun getFirstMessageOfUser(otherUserId: Int): ChatMessages? {
        val messagesList = getMessages(otherUserId)
        if (messagesList != null && messagesList.size > 0) return messagesList.first()
        return null
    }

    @Throws(Exception::class)
    override fun getLastMessageOfUser(otherUserId: Int): ChatMessages? {
        val messagesList = getMessages(otherUserId)
        if (messagesList != null && messagesList.size > 0) return messagesList.last()
        return null
    }

    @Throws(Exception::class)
    override fun getChatMessage(uniqueId: String): ChatMessages? =
        realm.where<ChatMessages>().equalTo(RealmConstants.UNIQUE_ID, uniqueId).findFirst()

    /**
     * To get messages between 2 users i.e.
     *
     * */
    @Throws(Exception::class)
    override fun getChatMessages(otherUserId: Int, userId: Int): RealmResults<ChatMessages> =
        realm.where<ChatMessages>()
            .`in`(RealmConstants.RECEIVER_ID, arrayOf(otherUserId, userId))
            .`in`(RealmConstants.SENDER_ID, arrayOf(otherUserId, userId))
            .sort(RealmConstants.CREATED_DATE, Sort.ASCENDING)
            .findAll()

    @Throws(Exception::class)
    override fun insertOrUpdateMessage(message: ChatMessages) {
        realm.beginTransaction()
        val chatMessages = realm.copyToRealmOrUpdate(message)
        if (chatMessages != null) {
            val chatUser = getChatConversion(chatMessages.getConversionId())
            chatUser?.setLastMessageDate(chatMessages.getCreatedDate())
        }
        realm.commitTransaction()
    }

    @Throws(Exception::class)
    override fun insertOrUpdateMessages(messagesList: MutableList<ChatMessages>) {
        realm.beginTransaction()
        val chatMessagesList = realm.copyToRealmOrUpdate(messagesList)
        chatMessagesList?.forEach {
            val chatUser = getChatConversion(it.getConversionId())
            chatUser?.setLastMessageDate(it.getCreatedDate())
        }
        realm.commitTransaction()
    }

    @Throws(Exception::class)
    override fun insertOrUpdateMessageFromJson(response: JSONObject) {
        realm.beginTransaction()
        val chatMessage = realm.createOrUpdateObjectFromJson(ChatMessages::class.java, response)
        if (chatMessage != null && chatMessage.getSenderId() != preference.getUserId().toInt())
            chatMessage.setNotMe()

        if (chatMessage != null) {
            val chatUser = getChatConversion(chatMessage.getConversionId())
            chatUser?.setLastMessageDate(chatMessage.getCreatedDate())
        }

        realm.commitTransaction()
    }

    @Throws(Exception::class)
    override fun updateMessage(response: JSONObject) {
        val uniqueId = response.optString(SocketConstants.Parameters.UniqueId, "")
        val chatMessage = getChatMessage(uniqueId)
        if (chatMessage != null) {

            val conversionId = response.optInt(RealmConstants.CONVERSION_ID, 0)
            val messageDate = response.optString(RealmConstants.CREATED_DATE, "")

            realm.beginTransaction()
            //realm.createOrUpdateObjectFromJson(ChatMessages::class.java, response)
            chatMessage.setMessageId(response.optInt(RealmConstants.MESSAGE_ID, 0))
            chatMessage.setMessageDate(messageDate)
            chatMessage.setConversionId(conversionId)
            chatMessage.setMessageSent(true)

            if (response.optString(RealmConstants.MESSAGE_TYPE, "") == AppConstants.MessageType.IMAGE) {
                val media = response.optJSONObject(ApiConstants.MEDIA)
                if (media != null) {
                    val mediaDetails = chatMessage.getChatMedia()
                    mediaDetails.media_id = media.optString(RealmConstants.MEDIA_ID, "")
                    mediaDetails.mediaUploadStatus = AppConstants.MediaStatus.MediaUploadSuccess
                    mediaDetails.setMediaUrl(media.optString(ApiConstants.CHAT_IMAGE, ""))
                }
            }

            val chatUser = getChatConversion(conversionId)
            chatUser?.setLastMessageDate(messageDate)

            realm.commitTransaction()
        }
    }

    // TODO : This method will be called only if media uploaded Successfully
    /*override fun updateMediaDetails(mediaName: String, uniqueId: String) {
        val chatMessage = getChatMessage(uniqueId)
        if (chatMessage != null) {
            val mediaDetails = chatMessage.getChatMedia()
            realm.beginTransaction()
            mediaDetails.mediaUploadStatus = AppConstants.MediaUploadStatus.MediaUploadSuccess
            mediaDetails.mediaName = mediaName
            mediaDetails.setMediaUrl(mediaName)
            realm.commitTransaction()
        }
    }*/

    @Throws(Exception::class)
    override fun updateMediaStatus() {
        realm.executeTransactionAsync { realmAsync ->
            try {
                val imagesList = realmAsync.where<ChatMessages>()
                    .equalTo(RealmConstants.MESSAGE_TYPE, AppConstants.MessageType.IMAGE).findAll()
                if ((imagesList != null) && (imagesList.size > 0)) {
                    imagesList.forEach {
                        val status = it.getChatMedia().mediaDownloadStatus
                        if ((status == AppConstants.MediaStatus.MediaUploading) ||
                            (status == AppConstants.MediaStatus.MediaDownloading) ||
                            (it.getChatMedia().mediaDownloadProgress > 0)
                        ) {
                            it.getChatMedia().mediaDownloadProgress = 0
                            it.getChatMedia().mediaDownloadStatus = AppConstants.MediaStatus.Unknown
                            it.getChatMedia().mediaUploadStatus = AppConstants.MediaStatus.Unknown
                        }
                    }
                }
            } catch (e: Exception) {
                Logs.printMessages("executeTransactionAsync", e.message)
            }
        }
    }

    @Throws(Exception::class)
    override fun updateMediaUploadStatus(mediaStatus: Int, uniqueId: String) {
        val chatMessage = getChatMessage(uniqueId)
        if (chatMessage != null) {
            val mediaDetails = chatMessage.getChatMedia()
            realm.beginTransaction()
            mediaDetails.mediaUploadStatus = mediaStatus
            realm.commitTransaction()
        }
    }

    @Throws(Exception::class)
    override fun updateMediaName(fileName: String, uniqueId: String) {
        val chatMessage = getChatMessage(uniqueId)
        if (chatMessage != null) {
            val mediaDetails = chatMessage.getChatMedia()
            realm.beginTransaction()
            mediaDetails.mediaUploadStatus = AppConstants.MediaStatus.Unknown
            mediaDetails.mediaPath = fileName
            realm.commitTransaction()
        }
    }

    @Throws(Exception::class)
    override fun updateDownloadProgress(progress: Float, uniqueId: String) {
        val chatMessage = getChatMessage(uniqueId)
        if (chatMessage != null) {
            val mediaDetails = chatMessage.getChatMedia()
            realm.beginTransaction()
            mediaDetails.mediaDownloadProgress = progress.toInt()
            realm.commitTransaction()
        }
    }

    @Throws(Exception::class)
    override fun updateDownloadStatus(downloadStatus: Int, uniqueId: String) {
        val chatMessage = getChatMessage(uniqueId)
        if (chatMessage != null) {
            val mediaDetails = chatMessage.getChatMedia()
            realm.beginTransaction()
            mediaDetails.mediaDownloadStatus = downloadStatus
            realm.commitTransaction()
        }
    }

    @Throws(Exception::class)
    override fun getPreviousMessages(otherUserId: Int, userId: Int, firstMessageId: Int):
            RealmResults<ChatMessages> = realm.where<ChatMessages>()
        .`in`(RealmConstants.RECEIVER_ID, arrayOf(otherUserId, userId))
        .`in`(RealmConstants.SENDER_ID, arrayOf(otherUserId, userId))
        .sort(RealmConstants.CREATED_DATE, Sort.DESCENDING)
        .limit(firstMessageId.toLong())
        .findAll()
        .sort(RealmConstants.CREATED_DATE, Sort.ASCENDING)

    @Throws(Exception::class)
    override fun clearDatabase() {
        realm.beginTransaction()
        realm.deleteAll()
        realm.commitTransaction()
    }

    private fun getMessages(otherUserId: Int) =
        realm.where<ChatMessages>().equalTo(RealmConstants.RECEIVER_ID, otherUserId).or()
            .equalTo(RealmConstants.SENDER_ID, otherUserId)
            .sort(RealmConstants.CREATED_DATE, Sort.ASCENDING).findAll()
}