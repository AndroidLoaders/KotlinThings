package com.app.tagglifedatingapp.database.manager

import com.app.tagglifedatingapp.models.ChatMessages
import com.app.tagglifedatingapp.models.ChatUser
import io.realm.Realm
import io.realm.RealmResults
import org.json.JSONObject

interface RealmInteractor {

    val realm: Realm

    @Throws(Exception::class)
    fun cancelTransaction()

    @Throws(Exception::class)
    fun removeAllChatUsers()

    @Throws(Exception::class)
    fun saveConversations(chatUserList: MutableList<ChatUser>)

    @Throws(Exception::class)
    fun saveConversation(jsonObject: JSONObject)

    @Throws(Exception::class)
    fun getChatConversions(): RealmResults<ChatUser>

    @Throws(Exception::class)
    fun getChatConversion(conversionId: Int): ChatUser?

    @Throws(Exception::class)
    fun getLastMessageOfUser(otherUserId: Int): ChatMessages?

    @Throws(Exception::class)
    fun getFirstMessageOfUser(otherUserId: Int): ChatMessages?

    @Throws(Exception::class)
    fun getUnreadMessages(otherUserId: Int): RealmResults<ChatMessages>?

    @Throws(Exception::class)
    fun getUnreadMessagesForAllUsers(): MutableMap<String, MutableList<ChatMessages>>

    @Throws(Exception::class)
    fun insertOrUpdateMessages(messagesList: MutableList<ChatMessages>)

    @Throws(Exception::class)
    fun insertOrUpdateMessage(message: ChatMessages)

    @Throws(Exception::class)
    fun insertOrUpdateMessageFromJson(response: JSONObject)

    @Throws(Exception::class)
    fun getChatMessage(uniqueId: String): ChatMessages?

    @Throws(Exception::class)
    fun getChatMessages(otherUserId: Int, userId: Int): RealmResults<ChatMessages>

    @Throws(Exception::class)
    fun readAllMessages(otherUserId: Int)

    @Throws(Exception::class)
    fun updateMessage(response: JSONObject)

    @Throws(Exception::class)
    fun updateMediaUploadStatus(mediaStatus: Int, uniqueId: String)

    @Throws(Exception::class)
    fun updateMediaName(fileName: String, uniqueId: String)

    @Throws(Exception::class)
    fun updateDownloadProgress(progress: Float, uniqueId: String)

    @Throws(Exception::class)
    fun updateDownloadStatus(downloadStatus: Int, uniqueId: String)

    @Throws(Exception::class)
    fun updateMediaStatus()

    @Throws(Exception::class)
    fun getPreviousMessages(otherUserId: Int, userId: Int, firstMessageId: Int): RealmResults<ChatMessages>

    @Throws(Exception::class)
    fun clearDatabase()
}