package com.app.tagglifedatingapp.database.configuration

import io.realm.DynamicRealm
import io.realm.Realm
import io.realm.RealmMigration

class MyMigration : RealmMigration {

    override fun migrate(realm: DynamicRealm, oldVersion: Long, newVersion: Long) {
        var oldVersion = oldVersion
        val schema = Realm.getInstance(RealmConfig.getRealmConfig()).schema
        if (oldVersion == 1L) {
            try {
            } catch (e: Exception) {
                println("TAG -- MyMigration --> " + e.message)
            }
            oldVersion++
        }
    }
}