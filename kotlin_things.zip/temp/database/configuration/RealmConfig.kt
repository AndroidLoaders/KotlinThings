package com.app.tagglifedatingapp.database.configuration

import android.content.Context
import com.app.tagglifedatingapp.R
import io.realm.Realm
import io.realm.RealmConfiguration

class RealmConfig {

    private lateinit var realmConfig: RealmConfiguration

    companion object {
        private var instance: RealmConfig? = null
        fun getInstance(context: Context) {
            if (instance == null) instance = RealmConfig()
            instance!!.getRealmInstance(context)
            Realm.getInstance(instance!!.realmConfig)
        }

        fun getRealmConfig() = instance!!.realmConfig
    }

    private fun createRealmInstance(context: Context) {
        realmConfig = RealmConfiguration.Builder()
            .name("NIPL" + context.getString(R.string.app_name) + ".realm").schemaVersion(1L)
            .migration(MyMigration())
            .deleteRealmIfMigrationNeeded().build()
    }

    private fun getRealmInstance(context: Context) {
        Realm.init(context)
        createRealmInstance(context)
    }
}