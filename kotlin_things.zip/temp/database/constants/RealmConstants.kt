package com.app.tagglifedatingapp.database.constants

object RealmConstants {

    const val UNIQUE_ID = "unique_chat_id"
    const val MEDIA_ID = "media_id"
    const val MESSAGE_ID = "message_id"
    const val CONVERSION_ID = "conversion_id"
    const val SENDER_ID = "sender_id"
    const val RECEIVER_ID = "receiver_id"
    const val MESSAGE_TYPE = "message_type"
    const val MESSAGE_TYPE_CAPTION = "message_type_caption"
    const val MESSAGE = "message"
    const val CREATED_DATE = "created_date"
    const val LAST_MESSAGE_ID = "last_message_date"
    const val IS_READ_MESSAGE = "is_read_message"
    const val ME = "me"
    const val IS_MESSAGE_SENT = "isMessagesSent"
}