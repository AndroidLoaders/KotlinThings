package com.app.tagglifedatingapp.utility

import android.os.AsyncTask
import android.util.Pair
import com.app.tagglifedatingapp.R
import com.app.tagglifedatingapp.TaggLifeApplication
import com.app.tagglifedatingapp.callbacks.DownloadInitialized
import com.app.tagglifedatingapp.networkadapter.apiconstants.ApiConstants
import okhttp3.ResponseBody
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.io.*

object DownloadManager {

    private val TAG = DownloadManager::class.java.simpleName

    /*fun cancelDownload() {
        try {
            downloadManager?.imageDownloader?.cancel(true)
            FileIO.deleteFile(File(FileIO.getAppFolder(), imageName))
            downloadManager = null
        } catch (e: Exception) {
            Logs.printMessages(TAG, e.message)
        }
    }*/

    fun downloadFile(
        onDownloadInitialized: DownloadInitialized, position: Int, imageName: String,
        fileType: String
    ) {
        onDownloadInitialized.onDownloadStarted(position)

        TaggLifeApplication.getInstance().getApiClient()
            .downloadImage(ApiConstants.CHAT_IMAGE_LOADER.plus(imageName))
            .enqueue(object : Callback<ResponseBody> {
                override fun onFailure(call: Call<ResponseBody>, throwable: Throwable) {
                    try {
                        onDownloadInitialized.onDownloadFailed(
                            position,
                            onDownloadInitialized.myContext.getString(R.string.something_wrong)
                        )
                        Logs.printMessages(TAG, throwable.message)
                    } catch (e: Exception) {
                        Logs.printMessages(TAG, e.message)
                    }
                }

                override fun onResponse(
                    call: Call<ResponseBody>, apiResponse: Response<ResponseBody>
                ) {
                    try {
                        if (apiResponse.isSuccessful) {

                            Logs.printMessages(TAG, "Download started ... ")

                            when (fileType) {
                                AppConstants.MessageType.IMAGE -> {
                                    ImageDownloader(onDownloadInitialized, position, imageName)
                                        .executeOnExecutor(
                                            AsyncTask.THREAD_POOL_EXECUTOR, apiResponse.body()
                                        )
                                }
                                else -> {
                                }
                            }
                        } else {
                            onDownloadInitialized.onDownloadFailed(
                                position,
                                onDownloadInitialized.myContext.getString(R.string.something_wrong)
                            )
                            Logs.printMessages(TAG, "Download failed 1 ... ")
                        }
                    } catch (e: Exception) {
                        onDownloadInitialized.onDownloadFailed(
                            position,
                            onDownloadInitialized.myContext.getString(R.string.something_wrong)
                        )
                        Logs.printMessages(TAG, e.message)
                    }
                }
            })
    }

    /*private fun <T> createService(serviceClass: Class<T>, baseUrl: String): T {
        val retrofit = Retrofit.Builder().baseUrl(baseUrl).client(OkHttpClient.Builder().build())
            .build()
        return retrofit.create(serviceClass)
    }*/

    private class ImageDownloader(
        private val onDownloadInitialized: DownloadInitialized, private val position: Int,
        private val imageName: String
    ) : AsyncTask<ResponseBody, Pair<Int, Long>, Void>() {

        private val TAG = ImageDownloader::class.java.simpleName

        override fun doInBackground(vararg urls: ResponseBody?): Void? {
            try {
                if (urls[0] != null) saveImage(urls[0]!!, imageName)
                else {
                    publishProgress(Pair(-1, -1L))
                    cancel(true)
                }
            } catch (e: Exception) {
                publishProgress(Pair(-1, -1L))
                Logs.printMessages(TAG, e.message)
            }
            return null
        }


        override fun onProgressUpdate(vararg progress: Pair<Int, Long>?) {
            super.onProgressUpdate(*progress)

            try {
                if (progress[0] != null) {
                    Logs.printMessages(TAG, progress[0]!!.second.toString() + " ")

                    if (progress[0]!!.second > 0) {
                        val currentProgress =
                            (progress[0]!!.first.toDouble() / progress[0]!!.second.toDouble() * 100).toInt()
                        Logs.printMessages(TAG, "onProgressUpdate ----> $currentProgress")
                        if (File(FileIO.AppFolderAbsolutePath, imageName).exists())
                            onDownloadInitialized.onProgressUpdate(position, currentProgress)
                    }

                    if ((progress[0]!!.first == 100) && (progress[0]!!.second == 100L)) {
                        Logs.printMessages(TAG, "File downloaded successfully ... ")
                        //onDownloadInitialized.onDownloadFinished(position, 100)
                        return
                    }

                    if (progress[0]!!.first == -1) {
                        Logs.printMessages(TAG, "Download failed ... ")
                        onDownloadInitialized.onDownloadFailed(position, "")
                    }

                    if (progress[0]!!.first == 0) {
                        Logs.printMessages(TAG, "Download started successfully ... ")
                        onDownloadInitialized.onDownloadStarted(position)
                    }
                }
            } catch (e: Exception) {
                Logs.printMessages(TAG, e.message)
                onDownloadInitialized.onDownloadFailed(position, "")
            }
        }

        private fun saveImage(body: ResponseBody, filename: String) {
            try {
                val destinationFile = File(FileIO.getAppFolder().path + File.separator + filename)

                var inputStream: InputStream? = null
                var outputStream: OutputStream? = null

                try {
                    val fileReader = ByteArray(4096)

                    val fileSize = body.contentLength()
                    var fileSizeDownloaded: Long = 0

                    inputStream = body.byteStream()
                    outputStream = FileOutputStream(destinationFile)

                    while (true) {
                        val read = inputStream.read(fileReader)

                        if (read == -1) break

                        Thread.sleep(300)
                        outputStream.write(fileReader, 0, read)

                        fileSizeDownloaded += read

                        publishProgress(Pair(fileSizeDownloaded.toInt(), fileSize))

                        Logs.printMessages(TAG, "file download : $fileSizeDownloaded of $fileSize")
                    }

                    outputStream.flush()

                    Logs.printMessages(TAG, destinationFile.parent)

                    publishProgress(Pair(100, 100L))
                    return
                } catch (e: Exception) {
                    publishProgress(Pair(-1, -1L))
                    e.printStackTrace()
                    Logs.printMessages(TAG, "Failed to save the file! --- " + e.message)
                    return
                } finally {
                    inputStream?.close()
                    outputStream?.close()
                }
            } catch (e: IOException) {
                publishProgress(Pair(-1, -1L))
                e.printStackTrace()
                Logs.printMessages(TAG, "Failed to save the file! --- " + e.message)
                return
            }
        }
    }
}